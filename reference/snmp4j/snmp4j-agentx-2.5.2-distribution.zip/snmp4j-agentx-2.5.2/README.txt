
SNMP4J-AgentX README
====================

In contrast to SNMP4J and SNMP4J-Agent which are
released under the Apachae 2.0 license, SNMP4J-AgentX
is released under the GNU Public License and a commercial
license.

Thus, if you want to use SNMP4J-AgentX without putting
your own code also under the GPL, you need to purchase
a commercial license. For details email to
sales@snmp4j.org.

The commercial license agreement can be found at
http://www.snmp4j.org/agentX/LICENSE_COMMERCIAL.txt
